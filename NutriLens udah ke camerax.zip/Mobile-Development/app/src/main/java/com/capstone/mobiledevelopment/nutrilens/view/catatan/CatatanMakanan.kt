package com.capstone.mobiledevelopment.nutrilens.view.catatan

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.capstone.mobiledevelopment.nutrilens.R
import com.capstone.mobiledevelopment.nutrilens.databinding.ActivityCatatanMakananBinding
import com.capstone.mobiledevelopment.nutrilens.databinding.ItemMacrosBinding
import com.capstone.mobiledevelopment.nutrilens.view.adapter.FoodAdapter
import com.capstone.mobiledevelopment.nutrilens.view.adapter.FoodItem
import com.capstone.mobiledevelopment.nutrilens.view.addstory.AddFoodActivity
import com.capstone.mobiledevelopment.nutrilens.view.customview.CustomBottomNavigationView
import com.capstone.mobiledevelopment.nutrilens.view.main.MainActivity
import com.capstone.mobiledevelopment.nutrilens.view.pilihan.PilihanMakanan
import com.capstone.mobiledevelopment.nutrilens.view.settings.SettingsActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton

class CatatanMakanan : AppCompatActivity() {
    private lateinit var binding: ActivityCatatanMakananBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCatatanMakananBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val foodList = listOf(
            FoodItem("Breakfast", "14 g", "14 g", "14 g", "500", "Nasi Gudeg Rawon"),
            FoodItem("Lunch", "14 g", "14 g", "14 g", "500", "Nasi Gudeg Rawon"),
            FoodItem("Dinner", "14 g", "14 g", "14 g", "500", "Nasi Gudeg Rawon")
        )

        // Setup RecyclerView
        val adapter = FoodAdapter(foodList)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        // Setup Macros Card
        binding.carbsProgressBar.progress = 75
        binding.fatProgressBar.progress = 100
        binding.proteinProgressBar.progress = 100
        binding.carbsValueTextView.text = "75/100 g"
        binding.fatValueTextView.text = "100/100 g"
        binding.proteinValueTextView.text = "100/100 g"
        binding.totalCalories.text = "1500/2400 Calories"

        // Initialize the custom bottom navigation view
        val bottomNavigationView = findViewById<CustomBottomNavigationView>(R.id.customBottomBar)
        bottomNavigationView.inflateMenu(R.menu.bottom_navigation_menu)

        val selectedItemId = intent.getIntExtra("selected_item", R.id.navigation_stats)
        bottomNavigationView.selectedItemId = selectedItemId
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_food -> {
                    val intent = Intent(this@CatatanMakanan, PilihanMakanan::class.java)
                    intent.putExtra("selected_item", R.id.navigation_food)
                    startActivity(intent)
                    true
                }

                R.id.navigation_profile -> {
                    val intent = Intent(this@CatatanMakanan, SettingsActivity::class.java)
                    intent.putExtra("selected_item", R.id.navigation_profile)
                    startActivity(intent)
                    true
                }

                R.id.navigation_stats -> {
                    val intent = Intent(this@CatatanMakanan, MainActivity::class.java)
                    intent.putExtra("selected_item", R.id.navigation_stats)
                    startActivity(intent)
                    true
                }

                R.id.navigation_documents -> {
                    // Activity ini sudah halaman statistik
                    true
                }

                else -> false
            }
        }

        // Add the FAB click listener
        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener {
            val intent = Intent(this@CatatanMakanan, AddFoodActivity::class.java)
            startActivity(intent)
        }
    }

}