package com.capstone.mobiledevelopment.nutrilens.view.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.capstone.mobiledevelopment.nutrilens.databinding.ItemCatatanBinding

data class FoodItem(
    val mealType: String,
    val carbs: String,
    val fat: String,
    val protein: String,
    val calories: String,
    val foodItem: String
)

class FoodAdapter(private val foodList: List<FoodItem>) :
    RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    class FoodViewHolder(val binding: ItemCatatanBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val binding = ItemCatatanBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FoodViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        val foodItem = foodList[position]
        holder.binding.mealTitle.text = foodItem.mealType
        holder.binding.carbsValue.text = foodItem.carbs
        holder.binding.fatValue.text = foodItem.fat
        holder.binding.proteinValue.text = foodItem.protein
        holder.binding.caloriesValue.text = foodItem.calories
        holder.binding.foodItem.text = foodItem.foodItem
    }

    override fun getItemCount(): Int = foodList.size
}